﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GMIS___Assignment_03.Model
{
    public class Student
    {
        public string studentId { get; set; }
        public string GivenName { get; set; }
        public string FamilyName { get; set; }
        public string Group_id { get; set; }
        public string Title{ get; set; }
        public string Campus { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Photo { get; set; }
        public string Category { get; set; }
    }
}
