﻿using GMIS___Assignment_03.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GMIS___Assignment_03.ViewModel
{
    public class StudentViewModel
    {
        public List<Student> Students { get; set; }
    }
}
