﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GMIS___Assignment_03.ViewModel
{
    Public class StudentMasterpageView
    {
        public List<StudentMAstepageView> StudentMasterpageViews{ get; set; }

    }
}
